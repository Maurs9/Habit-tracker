/*
 * Copyright (C) 2016-2021 Álinson Santos Xavier <git@axavier.org>
 *
 * This file is part of Loop Habit Tracker.
 *
 * Loop Habit Tracker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 *
 * Loop Habit Tracker is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

package org.isoron.uhabits.core.utils

import java.io.File
import java.io.FileInputStream

fun File.isSQLite3File(): Boolean {
    return FileInputStream(this).use { fis ->
        val sqliteHeader = "SQLite format 3".toByteArray()
        val buffer = ByteArray(sqliteHeader.size)
        val count = fis.read(buffer)
        count == sqliteHeader.size && buffer.contentEquals(sqliteHeader)
    }
}
